public class Taasl1PrintNumbers {
    //Write a function that prints the numbers from 1 to 100, each on a new line.
    public static void main(String[] args) {
        for (int i = 0; i < 100; i++) {
            System.out.println(i+1);
        }
    }

}
