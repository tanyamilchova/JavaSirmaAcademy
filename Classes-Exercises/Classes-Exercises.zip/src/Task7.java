public class Task7 {

}
