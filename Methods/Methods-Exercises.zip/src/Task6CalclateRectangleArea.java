public class Task6CalclateRectangleArea {
    public static void main(String[] args) {
        int a=3;
        int b=4;
        calculateRectangleArea(a,b);
    }
    public static void calculateRectangleArea(int a,int b){
        System.out.println(a*b);
    }
}
